import React, { useState, useEffect, useMemo } from "react";
import { Table, TableHeader, TableBody, TableRow, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useOrders, OrderData } from "@/contexts/OrdersContext";
import ConfirmModal from '../ConfirmModal/ConfirmModal';
import StatusFilterBar from "./StatusFilterBar";
import BulkActionsBar from "./BulkActionsBar";
import OrderTableHeader from "./OrderTableHeader";
import OrderTableRow from "./OrderTableRow";
import PaginationControls from "./PaginationControls";
import { useOrderActions } from "@/hooks/orders/useOrderActions";
import { getLabelFromApiStatus } from "@/lib/orderStatusMappings";
import toast from 'react-hot-toast';

export default function ProcessTable() {
    const {
        orders,
        loading,
        error,
        pagination,
        currentPage,
        selectedDays,
        selectedStatus,
        setCurrentPage,
        setSelectedDays,
        setSelectedStatus,
        refetch,
        deleteBulkOrders,
        bulkUpdateOrderStatus,
        updateOrderPriority,
    } = useOrders();

    const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
    const [selectedOrderIds, setSelectedOrderIds] = useState<string[]>([]);
    const [showBulkDeleteModal, setShowBulkDeleteModal] = useState(false);
    const [isBulkDeleting, setIsBulkDeleting] = useState(false);
    const [bulkStatusSelectValue, setBulkStatusSelectValue] = useState<string>("");
    const [showBulkStatusModal, setShowBulkStatusModal] = useState(false);
    const [isBulkStatusUpdating, setIsBulkStatusUpdating] = useState(false);
    const [pendingBulkStatus, setPendingBulkStatus] = useState<{
        orderIds: string[];
        newStatus: string;
    } | null>(null);
    const [showPriorityModal, setShowPriorityModal] = useState(false);
    const [priorityModalOrder, setPriorityModalOrder] = useState<OrderData | null>(null);
    const [prioritySelection, setPrioritySelection] = useState<'Dringend' | 'Normal'>('Normal');
    const [isPriorityUpdating, setIsPriorityUpdating] = useState(false);

    const {
        showConfirmModal,
        setShowConfirmModal,
        isDeleting,
        pendingAction,
        deleteLoading,
        handleDeleteOrder,
        executeDeleteOrder,
        handleInvoiceDownload,
    } = useOrderActions();


    // Memoized orders
    const memoizedOrders = useMemo(() => orders, [orders]);

    // Handle status filter
    const handleStatusFilter = (status: string) => {
        if (selectedStatus === status) {
            setSelectedStatus(null);
        } else {
            setSelectedStatus(status);
        }
        setSelectedOrderId(null);
        setSelectedOrderIds([]);
    };

    // Handle pagination
    const handlePageChange = (newPage: number) => {
        setCurrentPage(newPage);
        setSelectedOrderId(null);
        setSelectedOrderIds([]);
    };

    // Handle select all checkbox
    const handleSelectAll = () => {
        if (selectedOrderIds.length === memoizedOrders.length) {
            setSelectedOrderIds([]);
        } else {
            setSelectedOrderIds(memoizedOrders.map(order => order.id));
        }
    };

    // Handle individual checkbox
    const handleSelectOrder = (orderId: string, e: React.MouseEvent) => {
        e.stopPropagation();
        setSelectedOrderIds(prev => {
            if (prev.includes(orderId)) {
                return prev.filter(id => id !== orderId);
            } else {
                return [...prev, orderId];
            }
        });
    };

    // Check if all visible orders are selected
    const isAllSelected = memoizedOrders.length > 0 && selectedOrderIds.length === memoizedOrders.length;
    const isSomeSelected = selectedOrderIds.length > 0 && selectedOrderIds.length < memoizedOrders.length;

    // Clear selection when orders change
    useEffect(() => {
        if (orders.length > 0 && selectedOrderId) {
            const orderExists = orders.some(order => order.id === selectedOrderId);
            if (!orderExists) {
                setSelectedOrderId(null);
            }
        }
        // Clean up multiselect for orders that no longer exist
        if (selectedOrderIds.length > 0) {
            const validIds = selectedOrderIds.filter(id =>
                orders.some(order => order.id === id)
            );
            if (validIds.length !== selectedOrderIds.length) {
                setSelectedOrderIds(validIds);
            }
        }
    }, [orders, selectedOrderId, selectedOrderIds]);

    // Handle confirm modal actions
    const handleConfirm = async () => {
        if (pendingAction?.type === 'delete') {
            await executeDeleteOrder((id: string | null) => setSelectedOrderId(id));
        }
    };

    // Handle bulk delete
    const handleBulkDelete = (orderIds: string[]) => {
        setShowBulkDeleteModal(true);
    };

    const handleBulkStatusChange = (orderIds: string[], newStatus: string) => {
        if (orderIds.length === 0) return;
        setPendingBulkStatus({ orderIds, newStatus });
        setShowBulkStatusModal(true);
    };

    const executeBulkStatusChange = async () => {
        if (!pendingBulkStatus) return;
        setIsBulkStatusUpdating(true);
        try {
            await bulkUpdateOrderStatus(pendingBulkStatus.orderIds, pendingBulkStatus.newStatus);
            toast.success('Status erfolgreich aktualisiert');
            setShowBulkStatusModal(false);
            setPendingBulkStatus(null);
            setSelectedOrderIds([]);
            setBulkStatusSelectValue("");
        } catch (error) {
            console.error('Failed to update statuses:', error);
            toast.error('Fehler beim Aktualisieren des Status');
        } finally {
            setIsBulkStatusUpdating(false);
        }
    };

    useEffect(() => {
        if (selectedOrderIds.length === 0) {
            setBulkStatusSelectValue("");
        }
    }, [selectedOrderIds.length]);

    const executeBulkDelete = async () => {
        if (selectedOrderIds.length === 0) return;

        setIsBulkDeleting(true);
        try {
            await deleteBulkOrders(selectedOrderIds);
            toast.success(`${selectedOrderIds.length} ${selectedOrderIds.length === 1 ? 'Auftrag' : 'Aufträge'} erfolgreich gelöscht`);
            setSelectedOrderIds([]);
            setSelectedOrderId(null);
        } catch (error) {
            console.error('Failed to delete orders:', error);
            toast.error('Fehler beim Löschen der Aufträge');
        } finally {
            setIsBulkDeleting(false);
            setShowBulkDeleteModal(false);
        }
    };

    if (error) {
        return (
            <div className="mt-6 sm:mt-10 max-w-full flex justify-center items-center py-20">
                <div className="text-center">
                    <p className="text-red-600 mb-4">Fehler: {error}</p>
                    <Button onClick={refetch} variant="outline">
                        Erneut versuchen
                    </Button>
                </div>
            </div>
        );
    }

    return (
        <div className="mt-6 sm:mt-10 max-w-full overflow-x-auto">
            {selectedOrderIds.length === 0 ? (
                <StatusFilterBar
                    selectedDays={selectedDays}
                    selectedStatus={selectedStatus}
                    activeStep={-1}
                    onDaysChange={setSelectedDays}
                    onStatusFilter={handleStatusFilter}
                    onClearFilter={() => setSelectedStatus(null)}
                />
            ) : (
                <BulkActionsBar
                    selectedOrderIds={selectedOrderIds}
                    onClearSelection={() => setSelectedOrderIds([])}
                    onBulkDelete={handleBulkDelete}
                    onBulkStatusChange={handleBulkStatusChange}
                    statusValue={bulkStatusSelectValue}
                    onStatusValueChange={setBulkStatusSelectValue}
                />
            )}

            <Table className="table-fixed w-full">
                <TableHeader>
                    <OrderTableHeader
                        isAllSelected={isAllSelected}
                        isSomeSelected={isSomeSelected}
                        onSelectAll={handleSelectAll}
                    />
                </TableHeader>
                <TableBody>
                    {loading ? (
                        <TableRow>
                            <TableCell colSpan={12} className="text-center py-20">
                                <div className="flex flex-col items-center justify-center">
                                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                                    <p className="text-gray-600">Aufträge werden geladen...</p>
                                </div>
                            </TableCell>
                        </TableRow>
                    ) : memoizedOrders.length === 0 ? (
                        <TableRow>
                            <TableCell colSpan={12} className="text-center py-20">
                                <div className="flex flex-col items-center justify-center">
                                    <p className="text-gray-600 mb-4 text-lg">Keine Aufträge gefunden</p>
                                    <Button onClick={refetch} variant="outline">
                                        Aktualisieren
                                    </Button>
                                </div>
                            </TableCell>
                        </TableRow>
                    ) : (
                        memoizedOrders.map((order) => (
                            <OrderTableRow
                                key={order.id}
                                order={order}
                                isSelected={selectedOrderIds.includes(order.id)}
                                isRowSelected={selectedOrderId === order.id}
                                deleteLoading={deleteLoading}
                                onRowClick={setSelectedOrderId}
                                onCheckboxChange={handleSelectOrder}
                                onDelete={(id) => handleDeleteOrder(id, (id: string | null) => setSelectedOrderId(id))}
                                onInvoiceDownload={handleInvoiceDownload}
                                onPriorityClick={(orderData) => {
                                    setPriorityModalOrder(orderData);
                                    setPrioritySelection(orderData.priority || 'Normal');
                                    setShowPriorityModal(true);
                                }}
                            />
                        ))
                    )}
                </TableBody>
            </Table>

            <PaginationControls
                pagination={pagination}
                currentPage={currentPage}
                ordersCount={memoizedOrders.length}
                selectedStatus={selectedStatus}
                onPageChange={handlePageChange}
            />

            <ConfirmModal
                open={showConfirmModal}
                onOpenChange={setShowConfirmModal}
                title="Auftrag löschen bestätigen"
                description="Sind Sie sicher, dass Sie den Auftrag"
                orderName={pendingAction?.orderName}
                currentStatus={pendingAction?.currentStatus || ''}
                newStatus={pendingAction?.newStatus || ''}
                onConfirm={handleConfirm}
                confirmText="Ja, löschen"
                isDeleteAction={true}
                isLoading={isDeleting}
            />

            {/* Bulk Delete Confirmation Modal */}
            <ConfirmModal
                open={showBulkDeleteModal}
                onOpenChange={setShowBulkDeleteModal}
                title="Mehrere Aufträge löschen bestätigen"
                description={`Sind Sie sicher, dass Sie ${selectedOrderIds.length} ${selectedOrderIds.length === 1 ? 'Auftrag' : 'Aufträge'} löschen möchten?`}
                orderName={`${selectedOrderIds.length} ${selectedOrderIds.length === 1 ? 'Auftrag' : 'Aufträge'}`}
                currentStatus=""
                newStatus=""
                onConfirm={executeBulkDelete}
                confirmText="Ja, alle löschen"
                isDeleteAction={true}
                isLoading={isBulkDeleting}
            />

            <ConfirmModal
                open={showBulkStatusModal}
                onOpenChange={(open) => {
                    setShowBulkStatusModal(open);
                    if (!open) {
                        setIsBulkStatusUpdating(false);
                        setPendingBulkStatus(null);
                    }
                }}
                title="Status ändern bestätigen"
                description={`Sind Sie sicher, dass Sie den Status für ${pendingBulkStatus?.orderIds.length || 0} ${pendingBulkStatus && pendingBulkStatus.orderIds.length === 1 ? 'Auftrag' : 'Aufträge'}`}
                orderName={`${pendingBulkStatus?.orderIds.length || 0} ${pendingBulkStatus && pendingBulkStatus.orderIds.length === 1 ? 'Auftrag' : 'Aufträge'}`}
                currentStatus="Mehrere Statuswerte"
                newStatus={pendingBulkStatus ? getLabelFromApiStatus(pendingBulkStatus.newStatus) : ''}
                onConfirm={executeBulkStatusChange}
                confirmText="Bestätigen"
                isLoading={isBulkStatusUpdating}
            />

            <Dialog open={showPriorityModal} onOpenChange={(open) => {
                setShowPriorityModal(open);
                if (!open) {
                    setPriorityModalOrder(null);
                    setIsPriorityUpdating(false);
                }
            }}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle>Priorität ändern</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                        <p className="text-sm text-gray-600">
                            Wähle die gewünschte Priorität für <strong>{priorityModalOrder?.kundenname}</strong>
                        </p>
                        <div className="grid grid-cols-1 gap-2">
                            {(['Dringend', 'Normal'] as ('Dringend' | 'Normal')[]).map(option => (
                                <button
                                    key={option}
                                    className={`w-full border rounded-lg py-2 px-3 text-sm font-medium cursor-pointer transition ${prioritySelection === option
                                            ? option === 'Dringend'
                                                ? 'border-red-500 bg-red-50 text-red-600'
                                                : 'border-gray-400 bg-gray-100 text-gray-700'
                                            : 'border-gray-200 hover:border-gray-300 text-gray-600'
                                        }`}
                                    onClick={() => setPrioritySelection(option)}
                                >
                                    {option}
                                </button>
                            ))}
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" className="cursor-pointer" onClick={() => setShowPriorityModal(false)} disabled={isPriorityUpdating}>
                            Abbrechen
                        </Button>
                        <Button
                            className="cursor-pointer"
                            onClick={async () => {
                                if (!priorityModalOrder) return;
                                setIsPriorityUpdating(true);
                                try {
                                    await updateOrderPriority(priorityModalOrder.id, prioritySelection);
                                    toast.success('Priorität aktualisiert');
                                    setShowPriorityModal(false);
                                } catch (error) {
                                    console.error('Failed to update priority:', error);
                                    toast.error('Fehler beim Aktualisieren der Priorität');
                                } finally {
                                    setIsPriorityUpdating(false);
                                }
                            }}
                            disabled={isPriorityUpdating}
                        >
                            {isPriorityUpdating ? 'Aktualisiere...' : 'Speichern'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
