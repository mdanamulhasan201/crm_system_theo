import React from 'react'

export default function DashboardFeetF1rst() {
    return (
        <div>
            DashboardFeetF1rst
        </div>
    )
}
