import Notifications from "@/components/DashboardSettings/Notifications";

export default function NotificationsPage() {
    return <Notifications />;
} 