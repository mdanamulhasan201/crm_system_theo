import UserManagementAccessRights from "@/components/DashboardSettings/UserManagementAccessRights";

export default function UsersPage() {
    return <UserManagementAccessRights />;
} 