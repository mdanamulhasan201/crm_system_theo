import BasicSettings from "@/components/DashboardSettings/BasicSettings";

export default function SettingsProfilePage() {
    return <BasicSettings />;
}
