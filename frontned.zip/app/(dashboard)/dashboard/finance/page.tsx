import React from 'react'

export default function Finance() {
    return (
        <div>
            Finance
        </div>
    )
}
