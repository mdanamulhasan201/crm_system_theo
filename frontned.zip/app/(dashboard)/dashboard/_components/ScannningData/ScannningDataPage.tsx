'use client'
import { useRouter, useSearchParams } from 'next/navigation';
import React, { useState, useEffect } from 'react'
import QuestionSection from '../Scanning/QuestionSection';
import toast from 'react-hot-toast';
import ImagePreviewModal from '@/components/CustomerModal/ImagePreviewModal';
import { ScanData } from '@/types/scan';
import CustomerModal from '@/components/CustomerModal/CustomerModal';
import { useSingleCustomer } from '@/hooks/customer/useSingleCustomer';
import ScanDataDisplay from '@/components/Shared/ScanDataDisplay';

export default function ScannningDataPage({ scanData }: { scanData: ScanData }) {
    const router = useRouter();
    const searchParams = useSearchParams();
    const [modalOpen, setModalOpen] = useState(false);
    const [modalImg, setModalImg] = useState<string | null>(null);
    const [modalTitle, setModalTitle] = useState<string>('');
    const [modalType, setModalType] = useState<'image' | 'stl' | null>(null);
    const [stlUrl, setStlUrl] = useState<string | null>(null);
    const [addScanningModalOpen, setAddScanningModalOpen] = useState(false);

    // Use the existing hook for customer data management
    const { customer: currentScanData, updateCustomer, refreshCustomer, isUpdating, error } = useSingleCustomer(scanData.id);

    // State for editable scan data
    const [editableData, setEditableData] = useState({
        fusslange1: scanData.fusslange1 ?? '',
        fusslange2: scanData.fusslange2 ?? '',
        fussbreite1: scanData.fussbreite1 ?? '',
        fussbreite2: scanData.fussbreite2 ?? '',
        kugelumfang1: scanData.kugelumfang1 ?? '',
        kugelumfang2: scanData.kugelumfang2 ?? '',
        rist1: scanData.rist1 ?? '',
        rist2: scanData.rist2 ?? '',
        zehentyp1: scanData.zehentyp1 ?? '',
        zehentyp2: scanData.zehentyp2 ?? '',
        archIndex1: scanData.archIndex1 ?? '',
        archIndex2: scanData.archIndex2 ?? '',
    });

    // Sync editableData when scanData prop changes
    useEffect(() => {
        setEditableData({
            fusslange1: scanData.fusslange1 ?? '',
            fusslange2: scanData.fusslange2 ?? '',
            fussbreite1: scanData.fussbreite1 ?? '',
            fussbreite2: scanData.fussbreite2 ?? '',
            kugelumfang1: scanData.kugelumfang1 ?? '',
            kugelumfang2: scanData.kugelumfang2 ?? '',
            rist1: scanData.rist1 ?? '',
            rist2: scanData.rist2 ?? '',
            zehentyp1: scanData.zehentyp1 ?? '',
            zehentyp2: scanData.zehentyp2 ?? '',
            archIndex1: scanData.archIndex1 ?? '',
            archIndex2: scanData.archIndex2 ?? '',
        });
    }, [scanData]);

    // Check for query parameter to open manage customer modal automatically
    useEffect(() => {
        const manageCustomer = searchParams.get('manageCustomer');
        if (manageCustomer === 'true') {
            setAddScanningModalOpen(true);
        }
    }, [searchParams]);

    // Check if any field has changed
    const [originalData, setOriginalData] = useState(editableData);
    const isChanged = Object.keys(editableData).some(
        (key) => editableData[key as keyof typeof editableData] !== originalData[key as keyof typeof originalData]
    );

    // Handle input changes
    const handleInputChange = (field: string, value: string) => {
        setEditableData(prev => ({
            ...prev,
            [field]: value
        }));
    };

    const handleSaveChanges = async () => {
        try {
            const success = await updateCustomer(editableData);
            if (success) {
                setOriginalData(editableData);
                toast.success('Scan data updated successfully!');
            } else {
                toast.error('Failed to save changes');
            }
        } catch (err: any) {
            toast.error('Failed to save changes');
        }
    };

    // Helper to open modal with image
    const openModal = (img: string | null, title: string) => {
        setModalImg(img);
        setModalTitle(title);
        setModalType('image');
        setStlUrl(null);
        setModalOpen(true);
    };

    // Helper to open modal with STL
    const openStlModal = (stl: string | null, title: string) => {
        setStlUrl(stl);
        setModalTitle(title);
        setModalType('stl');
        setModalImg(null);
        setModalOpen(true);
    };

    // Use the data from hook or fallback to prop
    const displayData = currentScanData || scanData;

    const latestScreener = React.useMemo(() => {
        if (Array.isArray(displayData.screenerFile) && displayData.screenerFile.length > 0) {
            return displayData.screenerFile.reduce((latest, item) => {
                const latestDate = new Date(latest.updatedAt);
                const currentDate = new Date(item.updatedAt);
                return currentDate > latestDate ? item : latest;
            });
        }
        return null;
    }, [displayData.screenerFile]);

    const getLatestData = (fieldName: keyof Pick<ScanData, 'picture_10' | 'picture_23' | 'picture_11' | 'picture_24' | 'threed_model_left' | 'threed_model_right' | 'picture_17' | 'picture_16'>) => {
        if (latestScreener && latestScreener[fieldName]) {
            return latestScreener[fieldName];
        }
        return displayData[fieldName] || null;
    };

    return (
        <>
            {/* Image Preview Modal */}
            <ImagePreviewModal
                isOpen={modalOpen}
                onClose={() => setModalOpen(false)}
                modalImg={modalImg}
                modalTitle={modalTitle}
                modalType={modalType}
                stlUrl={stlUrl}
            />

            {/* Add New Scanning Modal */}
            <CustomerModal
                isOpen={addScanningModalOpen}
                onClose={() => {
                    setAddScanningModalOpen(false);
                    // Remove query parameter when modal is closed
                    const url = new URL(window.location.href);
                    url.searchParams.delete('manageCustomer');
                    router.replace(url.pathname + url.search);
                }}
                customerId={displayData.id}
                onSubmit={() => {
                    refreshCustomer();
                }}
            />

            <div className='flex justify-end mb-4 gap-4'>
                <button
                    onClick={() => {
                        setAddScanningModalOpen(true);
                        // Add query parameter to URL
                        const url = new URL(window.location.href);
                        url.searchParams.set('manageCustomer', 'true');
                        router.push(url.pathname + url.search);
                    }}
                    className='bg-[#62A07C] capitalize cursor-pointer text-white px-4 py-2 rounded hover:bg-[#62a07c98] transition text-sm'
                >
                    manage customer
                </button>
            </div>

            <div className='flex flex-col xl:flex-row justify-between items-start mb-6 gap-4'>
                <div className='w-full xl:w-7/12'>
                    <div className="flex items-center mb-4 md:mb-0">
                        <div className="font-bold text-xl capitalize">{displayData.vorname} {displayData.nachname}</div>
                    </div>

                    {/* Use the reusable ScanDataDisplay component */}
                    <ScanDataDisplay
                        scanData={displayData}
                        isEditable={true}
                        editableData={editableData}
                        onInputChange={handleInputChange}
                    >
                        {/* Additional content for the scan data section */}
                        {isChanged && (
                            <button
                                onClick={handleSaveChanges}
                                className='bg-[#4A8A6A] cursor-pointer text-white px-2 py-1 rounded hover:bg-[#4A8A6A]/80 transition text-sm'
                                disabled={isUpdating}
                            >
                                {isUpdating ? 'Saving...' : 'Save'}
                            </button>
                        )}
                        {error && (
                            <span className='ml-2 text-red-600 text-xs'>{error}</span>
                        )}
                    </ScanDataDisplay>
                </div>
                <div className='w-full xl:w-5/12'>
                    <QuestionSection customer={displayData} />
                </div>
            </div>

            {/* button section - now using latest data sorted by updatedAt */}
            <div className="mt-8 flex flex-col md:flex-row justify-between space-y-4 md:space-y-0">
                <div className="flex justify-center md:justify-start">
                    <div className="flex flex-wrap space-x-2">
                        <button className="border border-gray-300 cursor-pointer bg-white hover:bg-gray-100 px-4 py-1 text-sm my-1" onClick={() => openModal(getLatestData('picture_10'), 'Fersenneigung (Links)')}>Fersenneigung</button>
                        <button className="border border-gray-300 cursor-pointer bg-white hover:bg-gray-100 px-4 py-1 text-sm relative my-1" onClick={() => openModal(getLatestData('picture_23'), 'Plantaransicht (Links)')}>Plantaransicht</button>
                        <button className="border border-gray-300 cursor-pointer  bg-white hover:bg-gray-100 px-4 py-1 text-sm my-1" onClick={() => openStlModal(getLatestData('threed_model_left'), '3D-Modell (Links)')}>3D-Modell</button>
                        <button className="border border-gray-300 cursor-pointer bg-white hover:bg-gray-100 px-4 py-1 text-sm my-1" onClick={() => openModal(getLatestData('picture_17'), 'Sohlen Index (Links)')}>Sohlen Index</button>
                    </div>
                </div>

                <div className="flex justify-center md:justify-end">
                    <div className="flex flex-wrap space-x-2">
                        <button className="border border-gray-300 bg-white px-4 hover:bg-gray-100 cursor-pointer py-1 text-sm my-1" onClick={() => openModal(getLatestData('picture_11'), 'Fersenneigung (Rechts)')}>Fersenneigung</button>
                        <button className="border border-gray-300 bg-white px-4 hover:bg-gray-100 cursor-pointer py-1 text-sm my-1" onClick={() => openModal(getLatestData('picture_24'), 'Plantaransicht (Rechts)')}>Plantaransicht</button>
                        <button className="border border-gray-300 bg-white px-4 hover:bg-gray-100 cursor-pointer py-1 text-sm my-1" onClick={() => openStlModal(getLatestData('threed_model_right'), '3D-Modell (Rechts)')}>3D-Modell</button>
                        <button className="border border-gray-300 bg-white px-4 hover:bg-gray-100 cursor-pointer py-1 text-sm my-1" onClick={() => openModal(getLatestData('picture_16'), 'Sohlen Index (Rechts)')}>Sohlen Index</button>
                    </div>
                </div>
            </div>
        </>
    )
}
