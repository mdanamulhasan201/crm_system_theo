"use client";
import React from 'react'
import LastScanTable from '@/components/LastScans/LastScanTable'

export default function Page() {
    return (
        <div className="p-4">
            <LastScanTable />
        </div>
    )
}


