import React from 'react'

export default function InvoicePdfGenerate() {
  return (
    <div>
      
    </div>
  )
}
