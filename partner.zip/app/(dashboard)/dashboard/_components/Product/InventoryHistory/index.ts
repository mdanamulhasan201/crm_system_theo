export { default } from './InventoryHistory';
export type { InventoryHistoryRef, InventoryHistoryProps, Product, HistoryEntry } from './types';

