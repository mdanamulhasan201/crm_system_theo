// Re-export from the refactored structure
export { default } from './InventoryHistory/InventoryHistory';
export type { InventoryHistoryRef, InventoryHistoryProps, Product, HistoryEntry } from './InventoryHistory/types';
