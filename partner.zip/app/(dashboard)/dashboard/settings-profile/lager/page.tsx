import React from 'react'

export default function LagerPage() {
    return (
        <div>
            this is lager page
        </div>
    )
}
