import LanguageTimeZone from "@/components/DashboardSettings/LanguageTimeZone";

export default function LanguagePage() {
    return <LanguageTimeZone />;
} 