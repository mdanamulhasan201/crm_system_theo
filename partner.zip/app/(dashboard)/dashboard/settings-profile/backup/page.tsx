import BackupSettings from "@/components/DashboardSettings/BackupSettings";

export default function BackupPage() {
    return <BackupSettings />;
} 