import CustomerCommunication from "@/components/DashboardSettings/CustomerCommunication";

export default function CommunicationPage() {
    return <CustomerCommunication />;
} 