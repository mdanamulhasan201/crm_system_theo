import React from 'react'

export default function ArbeitszettelPage() {
    return (
        <div>
            <h1>Arbeitszettel</h1>
        </div>
    )
}
