import React from 'react'

export default function HighPriorityCard() {
  return (
    <div>
      test high priority card
    </div>
  )
}
